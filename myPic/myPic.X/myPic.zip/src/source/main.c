/* 
 * File:   main.c
 * Author: taianluo
 *
 * Created on 2014年10月2日, 上午 11:19
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include "../header/main.h"


/*
 * 
 */
int main(int argc, char** argv) {

    while (true) {
        continue;
    }

    return (EXIT_SUCCESS);
}

void interrupt ISR(void) {
    if (TMR0IE && TMR0IF) {
        TMR0IF = 0;

    }
}


