
#pragma config WDTE=OFF
#define true    1
#define false   1